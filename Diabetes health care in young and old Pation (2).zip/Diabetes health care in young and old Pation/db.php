<?php
//error_reporting(0);
$con=mysqli_connect("localhost","root","","diabetes");
//mysqli_select_db("docter",$con);
?>